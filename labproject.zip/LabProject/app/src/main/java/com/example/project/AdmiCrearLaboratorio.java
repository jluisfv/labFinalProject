package com.example.project;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.project.ui.administrador.BD;

public class AdmiCrearLaboratorio extends AppCompatActivity {
    EditText ednomblab, edcorre, edplanta;
    Button btnGuardar, btnCancelar;
    SQLiteDatabase bd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.admi_activity_crear_laboratorio);

        Spinner spinner = (Spinner) findViewById(R.id.spinner3);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.edificios_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        edcorre = findViewById(R.id.editText22);
        ednomblab = findViewById(R.id.editText20);
        edplanta = findViewById(R.id.editText23);
        btnGuardar = findViewById( R.id.btnGuardar );
        btnCancelar = findViewById( R.id.btnCancelar );

        BD objbase = new BD(getApplicationContext(),"DB",null,1);
        bd = objbase.getWritableDatabase();

        btnGuardar.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nlab = ednomblab.getText().toString();
                String corre = edcorre.getText().toString();
                String planta = edplanta.getText().toString();
                if(!nlab.equals("")){
                    if(!corre.equals("")){
                        if(!planta.equals("")){
                            bd.execSQL("insert into laboratorios(correlativoedif, noombrelab, planta) values('"+corre+"','"+nlab+"','"+planta+"')");
                            Toast.makeText( getApplicationContext(),"Laboratorio creado", Toast.LENGTH_LONG ).show();
                        }else {
                            Toast.makeText( getApplicationContext(),"Dato requerido", Toast.LENGTH_LONG ).show();
                        }
                    }else{
                        Toast.makeText( getApplicationContext(),"Dato requerido", Toast.LENGTH_LONG ).show();
                    }

                }else{
                    Toast.makeText( getApplicationContext(),"Dato requerido", Toast.LENGTH_LONG ).show();
                }
            }
        } );
        btnCancelar.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent regresar = new Intent(getApplicationContext(), AdmiMainActivity.class);
                startActivity(regresar);
            }
        } );

    }
}
