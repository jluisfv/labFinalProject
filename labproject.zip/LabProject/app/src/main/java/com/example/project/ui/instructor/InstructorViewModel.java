package com.example.project.ui.instructor;

import androidx.lifecycle.ViewModel;

public class InstructorViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
