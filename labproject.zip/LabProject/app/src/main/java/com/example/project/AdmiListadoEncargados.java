package com.example.project;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.project.ui.administrador.BD;

import java.util.ArrayList;

public class AdmiListadoEncargados extends AppCompatActivity {
    SQLiteDatabase bd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.admi_activity_listado_encargados);
        BD objbase = new BD(getApplicationContext(),"DB",null,1);
        bd = objbase.getWritableDatabase();
        setTitle("Encargados");

        ArrayList<String> historial = new ArrayList<>();
        String con = "select * from encargados";
        Cursor cc = bd.rawQuery(con, null);
        while (cc.moveToNext()){
            historial.add(cc.getString(1));
        }


        ArrayAdapter<String> data = new ArrayAdapter<String>(getApplicationContext(),android.R.layout.simple_list_item_1,historial);

        ListView listView = (ListView) findViewById(R.id.ListaEncargados);
        listView.setAdapter(data);


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent historial_detalle = new Intent(getApplicationContext(), AdmiModificarEncargado.class);
                startActivity(historial_detalle);
            }
        });

    }
}
