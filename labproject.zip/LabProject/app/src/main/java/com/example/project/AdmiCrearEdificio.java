package com.example.project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import com.example.project.ui.administrador.BD;

public class AdmiCrearEdificio extends AppCompatActivity {
    Button btnGuardar,btnCancelar;
    SQLiteDatabase bd ;
    EditText ededificio, edprefijo;
    RadioButton r1,r2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_admi_crear_edificio );
        BD objbase = new BD(getApplicationContext(),"DB",null,1);
        bd = objbase.getWritableDatabase();

        ededificio = findViewById(R.id.editText15);
        edprefijo = findViewById(R.id.editText16);
        r1 = findViewById(R.id.radioButton7);
        r2 = findViewById(R.id.radioButton8);
        btnCancelar = findViewById( R.id.btnCancelar );
        btnGuardar = findViewById( R.id.btnGuardar );

        btnGuardar.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String edificio = ededificio.getText().toString();
                String prefijo = edprefijo.getText().toString();
                String estado = (r1.isChecked())?"activo": "inactivo";
                if (!edificio.equals("")){
                  if(!prefijo.equals("")){
                      bd.execSQL("insert into edificios(correlativoedif, nombreedif, estado) values('"+prefijo+"','"+edificio+"','"+estado+"')");
                      Toast.makeText(getApplicationContext(), "datos guardados ", Toast.LENGTH_SHORT).show();
                  }else{
                      Toast.makeText(getApplicationContext(), "dato requerido", Toast.LENGTH_SHORT).show();
                  }
                }else{
                    Toast.makeText(getApplicationContext(), "dato requerido", Toast.LENGTH_SHORT).show();
                }

            }
        } );

        btnCancelar.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent regresar = new Intent( getApplicationContext(),AdmiMainActivity.class );
                startActivity( regresar );
            }
        } );
    }
}
