package com.example.project.ui.encargado;

import androidx.lifecycle.ViewModel;

public class EncargadoViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
