package com.example.project.ui.administrador;

import androidx.lifecycle.ViewModel;

public class AdmiViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
