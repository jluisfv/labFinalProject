package com.example.project.ui.administrador;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class BD extends SQLiteOpenHelper {
    public BD(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table users(tipouser text, nombreuser text, claveuser text)");
        String tipo = "administrador";
        String nombre = "administrador";
        String clave = "123";
        db.execSQL("insert into user(tipouser, nombreuser, claveuser) values('"+tipo+"','"+nombre+"','"+clave+"')");
        tipo = "encargado";
        nombre = "encargado";
        clave = "456";
        db.execSQL("insert into user(tipouser, nombreuser, claveuser) values('"+tipo+"','"+nombre+"','"+clave+"')");
        tipo = "instructor";
        nombre = "instructor";
        clave = "789";
        db.execSQL("insert into user(tipouser, nombreuser, claveuser) values('"+tipo+"','"+nombre+"','"+clave+"')");

        db.execSQL("create table edificios(correlativoedif text, nombreedif text, estado text)");
        tipo = "bj";
        nombre = "Benito Juarez";
        String esadoe = "activo";
        db.execSQL("insert into edificios(correlativoedif, nombreedif, estado) values('"+tipo+"','"+nombre+"','"+esadoe+"')");
        tipo = "fm";
        nombre = "Francisco Morazan";
        esadoe = "inactivo";
        db.execSQL("insert into edificios(correlativoedif, nombreedif, estado) values('"+tipo+"','"+nombre+"','"+esadoe+"')");

        db.execSQL("create table laboratorios(correlativoedif text, nombrelab text, planta text)");
        tipo = "bj";
        nombre = "lab1";
        clave = "3ra";
        db.execSQL("insert into laboratorios(correlativoedif, nombrelab, planta) values('"+tipo+"','"+nombre+"','"+clave+"')");
        tipo = "fm";
        nombre = "lab2";
        clave = "1ra";
        db.execSQL("insert into laboratorios(correlativoedif, nombrelab, planta) values('"+tipo+"','"+nombre+"','"+clave+"')");

        db.execSQL("create table ciclos(ciclo text, iniciociclo text, finciclo text, estadociclo text)");
        tipo = "01-2019";
        nombre = "15-01-2019";
        clave = "15-06-2019";
        String estado = "inactivo";
        db.execSQL("insert into ciclos(ciclo, iniciociclo, finciclo, estadociclo) values('"+tipo+"','"+nombre+"','"+clave+"','"+estado+"')");
        tipo = "02-2019";
        nombre = "25-06-2019";
        clave = "15-12-2019";
        estado = "activo";
        db.execSQL("insert into ciclos(ciclo, iniciociclo, finciclo, estadociclo) values('"+tipo+"','"+nombre+"','"+clave+"','"+estado+"')");

        db.execSQL("create table horarios(dias text, horaentrada text, horasalida text, fechainicio text, fechafin textt)");

        db.execSQL("create table encarlabs(nombrelab text, nombreencar text, horaentrada text, horasalida text)");

        db.execSQL("create table asignacion(nombrelab text, encag text, diasasig text, hentrada text, hsalida text)");

        db.execSQL("create table encargados(correo text, usuario text, clave text, estado text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
