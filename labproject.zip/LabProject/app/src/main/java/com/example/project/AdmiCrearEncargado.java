package com.example.project;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.project.ui.administrador.BD;

public class AdmiCrearEncargado extends AppCompatActivity {
    Button btnGuardar, btnCancelar;
    SQLiteDatabase bd ;
    EditText correo, usuario, clave;
    RadioButton ractivo,rinactivo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.admi_activity_crear_encargado);

        correo = findViewById(R.id.editText6);
        usuario = findViewById(R.id.editText7);
        clave = findViewById(R.id.editText8);
        ractivo = findViewById(R.id.radioButton3);
        rinactivo = findViewById(R.id.radioButton4);
        btnGuardar = findViewById( R.id.btnGuardar );
        btnCancelar = findViewById( R.id.btnCancelar );

        BD objbase = new BD(getApplicationContext(),"DB",null,1);
        bd = objbase.getWritableDatabase();
        btnGuardar.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mail = correo.getText().toString();
                String user = usuario.getText().toString();
                String pass = clave.getText().toString();
                String es = (ractivo.isChecked())?"activo":"inactivo";

                if(!mail.equals("")){
                    if(!user.equals("")){
                        if(!pass.equals("")){
                            bd.execSQL("insert into encargados(correo, usuario, clave, estado) values('"+mail+"','"+user+"','"+pass+"','"+es+"')");
                            String tip = "encargado";
                            bd.execSQL("insert into users(tipouser, nombreuser, claveuser) values('"+tip+"','"+user+"','"+pass+"')");
                            Toast.makeText( getApplicationContext(),"Encargado creado", Toast.LENGTH_LONG ).show();
                        }else {
                            Toast.makeText( getApplicationContext(),"dato necesario", Toast.LENGTH_LONG ).show();
                        }
                    }else{
                        Toast.makeText( getApplicationContext(),"dato necesario", Toast.LENGTH_LONG ).show();

                    }
                }else{
                    Toast.makeText( getApplicationContext(),"dato necesario", Toast.LENGTH_LONG ).show();
                }
            }
        } );

        btnCancelar.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent regresar = new Intent( getApplicationContext(), AdmiMainActivity.class ) ;
                startActivity( regresar );
            }
        } );

    }
}
